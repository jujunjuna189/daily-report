<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <link rel="preload" as="image" href="<?php echo e(asset('assets/logo/favicon.ico')); ?>">
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('assets/logo/favicon.ico')); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>

<body class="bg-slate-100">
    <div class="app">
        <?php if($nav_bar == true): ?>
        <nav class="bg-white">
            <ul class="flex gap-2 justify-center">
                <li class="py-6 px-5 font-medium hover:font-semibold text-slate-500 cursor-pointer hover:text-slate-900" onclick="location.href='<?= route('home') ?>'">Generate Report</li>
                <li class="py-6 px-5 font-medium hover:font-semibold text-slate-500 cursor-pointer hover:text-slate-900" onclick="location.href='<?= route('history') ?>'">History</li>
            </ul>
        </nav>
        <?php endif; ?>
        <main class="">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
<?php echo $__env->yieldContent('script'); ?>

</html><?php /**PATH D:\Project-Koding\Laravel\Ghigha_Store\formula-generator\formula-generator-v3\resources\views/layouts/app.blade.php ENDPATH**/ ?>