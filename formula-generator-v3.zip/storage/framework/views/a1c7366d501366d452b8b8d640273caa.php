<?php $__env->startSection('content'); ?>
<div class="h-screen w-screen overflow-hidden flex justify-center items-center">
    <div class="flex justify-center bg-white shadow rounded-lg">
        <div class="bg-radial from-white from-30% to-slate-300 flex items-center rounded-l-lg">
            <div class="px-10">
                <img src="<?php echo e(asset('assets/logo/logo.png')); ?>" alt="Logo" class="w-52" preload>
            </div>
        </div>
        <div class="px-10 py-5">
            <form method="post" action="<?php echo e(route('action.login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="pb-3">
                    <small>Welcome</small>
                    <div class="bg-linear-to-r from-cyan-500 to-blue-500 rounded-full w-full h-1"></div>
                </div>
                <div class="py-3">
                    <h3 class="text-2xl font-semibold">Login</h3>
                    <small>Sign In With Your Account</small>
                </div>
                <div class="">
                    <label for="email" class="text-slate-800 font-normal"><?php echo e(__('Email')); ?></label>

                    <div class="mt-1">
                        <input id="email" type="email" class="w-full bg-white border border-slate-300 rounded-sm py-2 px-3 text-sm focus:outline-none" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-Mail Address">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-sm text-red-800 w-[18rem]">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="mt-2">
                    <label for="password" class="text-slate-800 font-normal"><?php echo e(__('Password')); ?></label>

                    <div class="mt-2">
                        <input id="password" type="password" class="w-full bg-white border border-slate-300 rounded-sm py-2 px-3 text-sm focus:outline-none" name="password" placeholder="Password">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-sm text-red-800 w-[18rem]">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="mb-4 mt-12">
                    <button type="submit" class="bg-slate-700 text-white w-80 rounded-sm py-2 px-2 font-medium cursor-pointer">
                        <?php echo e(__('Login')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['nav_bar' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project-Koding\Laravel\Ghigha_Store\formula-generator\formula-generator-v3\resources\views/auth/login.blade.php ENDPATH**/ ?>