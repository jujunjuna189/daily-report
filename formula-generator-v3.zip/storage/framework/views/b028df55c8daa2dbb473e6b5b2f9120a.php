<?php if($paginator->hasPages()): ?>

<nav class="flex justify-center items-center gap-2 mt-4 text-sm">
    
    <?php if($paginator->onFirstPage()): ?>
    <span class="px-3 py-1 rounded bg-gray-200 text-gray-500 cursor-not-allowed">&laquo;</span>
    <?php else: ?>
    <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="px-3 py-1 rounded bg-slate-700 text-white hover:bg-slate-800">&laquo;</a>
    <?php endif; ?>

    
    <?php $__currentLoopData = $paginator->elements(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(is_string($element)): ?>
    <span class="px-3 py-1 text-gray-500"><?php echo e($element); ?></span>
    <?php endif; ?>

    <?php if(is_array($element)): ?>
    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($page == $paginator->currentPage()): ?>
    <span class="px-3 py-1 rounded bg-red-600 text-white"><?php echo e($page); ?></span>
    <?php else: ?>
    <a href="<?php echo e($url); ?>" class="px-3 py-1 rounded bg-gray-100 text-slate-900 hover:bg-gray-300"><?php echo e($page); ?></a>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php if($paginator->hasMorePages()): ?>
    <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="px-3 py-1 rounded bg-slate-700 text-white hover:bg-slate-800">&raquo;</a>
    <?php else: ?>
    <span class="px-3 py-1 rounded bg-gray-200 text-gray-500 cursor-not-allowed">&raquo;</span>
    <?php endif; ?>
</nav>
<?php endif; ?><?php /**PATH D:\Project-Koding\Laravel\Ghigha_Store\formula-generator\formula-generator-v3\resources\views/components/pagination/cs-pagination.blade.php ENDPATH**/ ?>